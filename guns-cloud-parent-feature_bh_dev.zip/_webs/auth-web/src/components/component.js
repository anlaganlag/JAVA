import Vue from 'vue'
import imgUpload from './img-upload/img-upload'

Vue.component('imgUpload', imgUpload)
