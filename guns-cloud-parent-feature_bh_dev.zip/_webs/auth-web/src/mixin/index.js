import  Vue from 'vue'
import turnPage from './turnPage'

Vue.mixin(turnPage)
