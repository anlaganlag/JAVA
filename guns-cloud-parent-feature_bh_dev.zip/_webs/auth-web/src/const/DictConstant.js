const DictConstant = {
    // 状态
    STATUS: {
        "ENABLE": 1,
        "DISABLE": 2
    }
}

export default DictConstant
