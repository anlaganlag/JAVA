<template>
  <el-footer class="sj-footer">
    <span>Copyright © 2019 stylefeng.cn All rights reserved.</span>
  </el-footer>
</template>

<script>
  export default {
    name: "SjFooter",
    data() {
      return {};
    },
    created() {},
    mounted() {},
    computed: {},
    props: [],
    methods: {}
  };
</script>

<style lang="scss" scoped>

  .sj-footer{
    height: 60px !important;
    line-height: 60px;
    span{
      font-size: 20px;
    }
  }
</style>
